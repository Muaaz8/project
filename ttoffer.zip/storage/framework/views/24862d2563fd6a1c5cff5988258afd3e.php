<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email Verification Code</title>
</head>
<body>
    <h1><?php echo e($data['title']); ?></h1>
    <p>Your Email Verification code is <b><?php echo e($data['body']); ?></b></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\ttoffer\resources\views/emails/email_verify.blade.php ENDPATH**/ ?>