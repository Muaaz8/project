<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Email Verification Code</title>
</head>
<body>
    <h1>{{$data['title']}}</h1>
    <p>Your Email Verification code is <b>{{$data['body']}}</b></p>
</body>
</html>