@include('layouts.front.top_links')
@yield('head')
</head>
<body>
@include('layouts.front.navbar')
@yield('main')
@include('layouts.front.modals')
@include('layouts.front.footer')